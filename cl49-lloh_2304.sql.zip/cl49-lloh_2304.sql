-- phpMyAdmin SQL Dump
-- version 4.0.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 09, 2013 at 12:11 PM
-- Server version: 5.5.34
-- PHP Version: 5.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cl49-lloh_2304`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrators`
--

CREATE TABLE IF NOT EXISTS `administrators` (
  `ADMINID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(80) NOT NULL DEFAULT '',
  `username` varchar(80) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`ADMINID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `administrators`
--

INSERT INTO `administrators` (`ADMINID`, `email`, `username`, `password`) VALUES
(1, 'admin@povertyproject.com', 'Admin', '40be4e59b9a2a2b5dffb918c0e86b3d7'),
(2, 'manager@povertyproject.com', 'manager', '0795151defba7a4b5dfa89170de46277');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `CATEGORYID` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(150) NOT NULL,
  PRIMARY KEY (`CATEGORYID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CATEGORYID`, `category_name`) VALUES
(1, 'Pellentesque eget nisit'),
(3, 'Donec venenatis nisi'),
(4, 'Cras quis elit'),
(5, 'Sed non metus porttitor');

-- --------------------------------------------------------

--
-- Table structure for table `category_post`
--

CREATE TABLE IF NOT EXISTS `category_post` (
  `CATEGORYID` int(11) NOT NULL,
  `POSTID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category_post`
--

INSERT INTO `category_post` (`CATEGORYID`, `POSTID`) VALUES
(3, 5),
(4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `COMMENT_ID` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_id` int(20) unsigned NOT NULL DEFAULT '0',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`COMMENT_ID`),
  KEY `comment_post_ID` (`comment_post_id`),
  KEY `comment_date` (`comment_date`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `setting` varchar(60) NOT NULL DEFAULT '',
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`setting`, `value`) VALUES
('site_name', 'Poverty Project'),
('site_email', 'admin@lloh.co.uk'),
('site_email_sender', 'LLOH  Admin'),
('items_per_page', '10'),
('max_thumb_width', '300'),
('max_thumb_height', '300'),
('facebook_social_link', 'https://www.facebook.com/pages/Leicester-League-of-Heroes/230250990472836'),
('twitter_social_link', 'https://twitter.com/LLoHeroes'),
('google_social_link', 'https://plus.google.com/communities/109547672437900473666'),
('youtube_social_link', 'http://www.youtube.com/channel/UCcGf1HwJi4ygLEtX1f8jCog'),
('video_link', 'http://www.youtube.com/watch?v=u8tzswROt70'),
('welcome_text', '<h1>Welcome to <strong>The Leicester League of Heroes</strong></h1>\n\n<h3><strong>Heed the call. Join the League. Fight local poverty.</strong></h3>\n\n<p>Leicester League of Heroes is a purpose-built website that has been set up to help unite local groups, organisations and institutions with the strength and goodwill of residents to tackle poverty together.</p>\n\n<p>Trusted groups and organisations around the city are able to create requests for goods and services they have identified which could help fight tackle poverty. Residents around the city are then able to respond to the identified needs via just a few simple clicks. Unwanted clothes, furniture, food and many more goods can now be redistributed to help tackle local poverty.</p>\n\n<p>For further information on how the League works, please click <strong>here</strong>.</p>\n'),
('latest_request_per_page', '5'),
('latest_request_ending_soon', '5'),
('metadescription', 'Take Action! Show your commitment now to end extreme poverty and join others on a journey to change the world.sss'),
('metakeywords', 'social, justice, living, dirty, laundry, global, we, writer, needs, world, poverty, eradication, theatre, publication,volunteer, yayasan, NGO, Bali, Indonesia, Vetiver, charity, ebpp,give back, non-profit, non profit, higher education, training, development'),
('registration_email', 'Dear {FIRSTNAME},<br/><br/>\n<p>Thank you for registering with Leicester League of Heroes. Your account will be activated as soon as our admin verifies your registration form. </p>\n<p>We will send you an email as soon as your account has been approved. In the meantime, if you do have any questions, please feel free to contact us.</p>\n<p>Yours faithfully,<br>\nLeicester League of Heroes</p>\n'),
('account_approval', '<p><strong>Congratulations!</strong></p>\n<p>Dear {FIRSTNAME},<br>\n</p>\n<p>Your group/organisation has been approved. Your group/organisation will now be visible within the directory section and you will be able to submit requests on behalf of residents which you have identified that require help. </p>\n<p>You can now login at {WEBSITE} using the username <strong>{USERNAME}</strong> and the password you created.</p>\n<p>Please ensure that you follow our terms and conditions and if unsure, please feel free to contact us. Term and Conditions can be found at the bottom of our website and be printed off for filing.<br>\n</p>\n<p>Yours faithfully,<br>\n  Leicester League of Heroes</p>\n'),
('forgot_password', 'Dear {FIRSTNAME},<br/><br/>\nYou have requested to reset your forgotten password for your account at our website. \n<br/><br/>\nPlease find below your updated credentials<br/>\nUsername: {USERNAME}<br/>\nPassword: {PASSWORD}<br/>\n<p>Yours faithfully,<br>\nLeicester League of Heroes</p>'),
('write_a_review', '<p>Dear <strong>{FIRSTNAME}</strong>,</p>\n<p>We have received your review and The Leicester League of Heroes admin will review your testimonial. Once it has been approved, it will be published on the site.</p>\n<p>If you have any questions please feel free to reach out to us at <a href="mailto:contactus@povertyproject.com">contactus@povertyproject.com</a></p>\n<p>The Leicester League of Heroes thanks you for your support and hope, that together, we can help beat poverty and help our fellow residents. </p>\n<p>Yours faithfully,<br>\nLeicester League of Heroes <br>\n</p>\n'),
('image1_url', 'http://www.lloh.co.uk/uploads/images/slider_01.jpg'),
('image2_url', 'http://www.lloh.co.uk/uploads/images/slider_02.jpg'),
('image3_url', 'http://www.lloh.co.uk/uploads/images/slider_03.jpg'),
('image4_url', 'http://www.lloh.co.uk/uploads/images/slider_04.jpg'),
('image5_url', 'http://www.lloh.co.uk/uploads/images/slider_05.jpg'),
('image6_url', 'http://www.lloh.co.uk/uploads/images/slider_06.jpg'),
('image7_url', ''),
('image8_url', ''),
('image9_url', ''),
('image10_url', ''),
('home_page_title_tag', 'The Leicester League of Heroes'),
('footer_left', 'Copyright © 2013 Poverty Project. All Rights Reserved.<br />\nDesign and Developed by <a href="http://www.alrayeswebsolutions.com/" target="_blank">Alrayes web solutions</a>'),
('footer_right', '<h6>Poverty Project</h6>\n 348A Harrison Road, Leicester, LE4 7AB, UK<br />\n<a href="mailto:uk@povertyproject.com" class="email">uk@povertyproject.com</a> | <span class="phone">08450 21 00 23</span> | <span class="phone">0208 123 8617</span>'),
('footer_links_block_1', '<h1>General Information</h1>\n<ul class="list_01">\n<li><a href="http://www.lloh.co.uk/news.html">News</a></li>\n<li><a href="http://www.lloh.co.uk/page/about-poverty-project.html">About US</a></li>\n<li><a href="http://www.lloh.co.uk/page/member-user-guide.html">Member User Guide</a></li>\n <li><a href="http://www.lloh.co.uk/page/how-to-become-a-member.html">How to become a member </a></li>\n<li><a href="http://www.lloh.co.uk/page/contact-us.html">Contact Us </a></li>\n</ul>'),
('footer_links_block_2', '<h1>Creating your own League</h1>\n<ul class="list_01">\n<li><a href="http://www.lloh.co.uk/page/setting-up.html">Setting up</a></li>\n<li><a href="http://www.lloh.co.uk/page/sustaining-your-league.html">Sustaining your League </a></li>\n<li><a href="http://www.lloh.co.uk/page/maintaining-your-league.html">Maintaining your League </a></li>\n</ul>'),
('footer_links_block_3', '<h1>Category Name</h1>\n                    <ul class="list_01">\n                        <li><a href="#">Pellentesque eget nisi</a></li>\n                        <li><a href="#">Pellentesque quis</a></li>\n                        <li><a href="#">Nullam gravida faucibus.</a></li>\n                        <li><a href="#">Cras quis elit</a></li>\n                        <li><a href="#">Sed non metus porttitor</a></li>\n                        <li><a href="#">Donec venenatis nisi</a></li>\n                    </ul>'),
('footer_links_block_4', '<h1>Category Name</h1>\n                    <ul class="list_01">\n                        <li><a href="#">Pellentesque eget nisi</a></li>\n                        <li><a href="#">Pellentesque quis</a></li>\n                        <li><a href="#">Nullam gravida faucibus.</a></li>\n                        <li><a href="#">Cras quis elit</a></li>\n                        <li><a href="#">Sed non metus porttitor</a></li>\n                        <li><a href="#">Donec venenatis nisi</a></li>\n                    </ul>');

-- --------------------------------------------------------

--
-- Table structure for table `directory`
--

CREATE TABLE IF NOT EXISTS `directory` (
  `DIRECTORY_ID` int(11) NOT NULL AUTO_INCREMENT,
  `organization_group` int(11) NOT NULL,
  `organization_name` varchar(200) NOT NULL,
  `organization_logo` varchar(250) NOT NULL DEFAULT 'noimage.png',
  `address` varchar(250) NOT NULL,
  `city` varchar(50) NOT NULL,
  `postalcode` char(20) NOT NULL,
  `telephone` char(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `status` int(1) DEFAULT '0',
  `date_posted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`DIRECTORY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `directory`
--

INSERT INTO `directory` (`DIRECTORY_ID`, `organization_group`, `organization_name`, `organization_logo`, `address`, `city`, `postalcode`, `telephone`, `email`, `website`, `status`, `date_posted`) VALUES
(1, 4, 'Abbey Primary School', 'logo_thumb.gif', 'Nulla facilisi, Sed adipiscing,\nTellus odio, vel semper,\nPulvinar consequat.\nCras sed tempor eros.', 'Leicester', 'LE4 7AB', '08450 21 00 23', 'helppeople@domainname.com', 'www.domainname.com', 1, '2013-10-12 08:59:37'),
(2, 4, 'Bicton CofE Primary School', 'noimage.png', 'Nulla facilisi, Sed adipiscing,\r\nTellus odio, vel semper,\r\nPulvinar consequat.\r\nCras sed tempor eros.', 'Leicester', 'LE4 7AB', '08450 21 00 23', 'wasim@alrayes.co.uk', 'www.domainname.com', 1, '2013-10-12 09:31:07'),
(3, 4, 'British Forces School', 'noimage.png', 'Nulla facilisi, Sed adipiscing,\nTellus odio, vel semper,\nPulvinar consequat.\nCras sed tempor eros.', 'Leicester', 'LE4 7AB', '08450 21 00 23', 'wasim@alrayes.co.uk', 'www.domainname.com', 1, '2013-10-12 09:31:59'),
(4, 4, 'Mount Pleasant School', 'noimage.png', 'Nulla facilisi, Sed adipiscing,\r\nTellus odio, vel semper,\r\nPulvinar consequat.\r\nCras sed tempor eros.', 'Leicester', 'LE4 7AB', '08450 21 00 23', 'wasim@alrayes.co.uk', 'www.domainname.com', 1, '2013-10-12 09:32:44'),
(5, 4, 'Camphill Rudolf Steiner Schools', 'noimage.png', 'Nulla facilisi, Sed adipiscing,\r\nTellus odio, vel semper,\r\nPulvinar consequat.\r\nCras sed tempor eros.', 'Leicester', 'LE4 7AB', '08450 21 00 23', 'wasim@alrayes.co.uk', 'www.domainname.com', 1, '2013-10-12 09:33:26'),
(6, 4, 'Banchory-Devenick School', '10-13-2013_10-04-21_PM.png', 'Nulla facilisi, Sed adipiscing,\nTellus odio, vel semper,\nPulvinar consequat.\nCras sed tempor eros.', 'Leicester', 'LE4 7AB', '08450 21 00 23', 'helppeople@domainname.com', 'www.domainname.com', 1, '2013-10-12 11:17:49'),
(7, 1, 'LLOH Test', 'wasim.jpg', 'Test 1\ntest 2\ntest 3\ntest ', 'Leicester', 'LE4 7AB', '447855255461', 'email@wasimismail.com', 'www.alrayes.co.uk', 1, '2013-11-03 12:01:03'),
(8, 8, 'Aqsa Travels', 'wasim1.jpg', 'test test test', 'Leicester', 'LE4 7AB', '447855255461', 'email@wasimismail.com', 'www.alrayes.co.uk', 1, '2013-11-03 13:00:10');

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE IF NOT EXISTS `donations` (
  `DONATE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `POST_ID` int(11) NOT NULL,
  `POST_MEMBER_ID` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(2000) NOT NULL,
  `telephone` varchar(2000) NOT NULL,
  `mobile` varchar(2000) NOT NULL,
  `email` varchar(2000) NOT NULL,
  `date_posted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`DONATE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`DONATE_ID`, `POST_ID`, `POST_MEMBER_ID`, `first_name`, `last_name`, `telephone`, `mobile`, `email`, `date_posted`) VALUES
(1, 1, 1, 'Rohit', 'Sharma', '0172-28652', '9915101782', 'atul.sood@gmail.com', '2013-10-29 19:48:10'),
(2, 4, 4, 'Test Donate', 'Test Donate ', '088892198219', '821982102', 'mohammed.w.ismail@bt.com', '2013-10-30 16:56:05'),
(3, 3, 1, 'sarfraz', 'khan', '', '0792786410', 'safnkhan@hotmail.com', '2013-10-31 00:01:53'),
(4, 7, 4, 'sarfraz', 'khan', '', '', 'sarfraznawazkhan@yahoo.co.uk', '2013-10-31 17:02:44'),
(5, 10, 6, 'saf', 'khan', '0789278641', '', 'sarfraznawazkhan@gmail.com', '2013-11-03 16:24:41');

-- --------------------------------------------------------

--
-- Table structure for table `group_type`
--

CREATE TABLE IF NOT EXISTS `group_type` (
  `GROUPID` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(150) NOT NULL,
  PRIMARY KEY (`GROUPID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `group_type`
--

INSERT INTO `group_type` (`GROUPID`, `group_name`) VALUES
(1, 'AIG'),
(2, 'Charity'),
(3, 'Community Centre'),
(4, 'Educational'),
(5, 'Elderly '),
(6, 'Faith Building'),
(7, 'Family Support'),
(8, 'Foodbank'),
(9, 'Health and Welfare'),
(10, 'Police'),
(11, 'Sports'),
(12, 'Women'),
(13, 'Yong People');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE IF NOT EXISTS `media` (
  `MEDIA_ID` int(11) NOT NULL AUTO_INCREMENT,
  `media_type` char(100) NOT NULL DEFAULT 'video',
  `media_title` varchar(200) NOT NULL,
  `media_path` varchar(150) NOT NULL,
  `media_status` char(100) NOT NULL DEFAULT 'published',
  `media_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`MEDIA_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`MEDIA_ID`, `media_type`, `media_title`, `media_path`, `media_status`, `media_date`) VALUES
(1, 'image', 'Image1', 'ngc6240.jpg', 'published', '2013-10-23 05:10:10'),
(2, 'image', 'Image2', 'image-1.jpg', 'published', '2013-10-23 05:10:23'),
(3, 'image', 'Image3', 'image-2.jpg', 'published', '2013-10-23 05:10:55'),
(4, 'image', 'Image4', 'image-3.jpg', 'published', '2013-10-23 05:11:08'),
(5, 'image', 'Image5', 'image-6.jpg', 'published', '2013-10-23 05:11:26'),
(7, 'image', 'Image6', 'a2204.jpg', 'published', '2013-10-23 07:17:21'),
(8, 'video', 'Global Poverty Project', 'http://www.youtube.com/watch?v=B1m23LEZqso', 'published', '2013-10-23 07:11:36'),
(9, 'video', 'Hugh Evans on Why His Global Poverty Project Doesn''t Just Treat', 'http://www.youtube.com/watch?v=9hjbPTCCFoU', 'published', '2013-10-23 07:13:06'),
(10, 'video', 'Hugh Jackman TV Commercial for the Global Poverty Project', 'http://www.youtube.com/watch?v=ckhD5NksrLI', 'published', '2013-10-23 07:13:57'),
(11, 'video', 'Poverty Project Interviews for Lost Nation', 'http://www.youtube.com/watch?v=VpGtZMAaR6Q', 'published', '2013-10-23 07:14:39'),
(12, 'video', 'Current Global Issues Poverty Project', 'http://www.youtube.com/watch?v=E0nP7Spigzg', 'published', '2013-10-23 07:15:13'),
(13, 'video', 'Poverty Project - Mubin Haq on benefits', 'http://www.youtube.com/watch?v=kdsJq8eDw-o', 'published', '2013-10-23 07:15:37'),
(15, 'video', 'Test Video', 'http://www.youtube.com/watch?v=A_mT4XnTiUI', 'published', '2013-10-29 04:59:39'),
(16, 'image', 'Poverty Event', 'IMG_20130828_222647.jpg', 'published', '2013-11-03 11:34:12'),
(17, 'video', 'Prank', 'http://youtu.be/Xrvn1aV-b4E', 'published', '2013-11-03 11:36:06');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `USERID` bigint(20) NOT NULL AUTO_INCREMENT,
  `gender` varchar(6) NOT NULL DEFAULT '',
  `firstname` varchar(60) NOT NULL DEFAULT '',
  `lastname` varchar(60) NOT NULL DEFAULT '',
  `organization_name` varchar(200) NOT NULL,
  `group_type` int(11) NOT NULL,
  `email` varchar(80) NOT NULL DEFAULT '',
  `username` varchar(80) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `photo` varchar(55) NOT NULL DEFAULT 'noimage.png',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `address` varchar(150) NOT NULL DEFAULT '',
  `city` varchar(80) NOT NULL DEFAULT '',
  `postal_code` varchar(100) NOT NULL DEFAULT '',
  `directory_listing_approval` char(1) NOT NULL DEFAULT '0',
  `submit_request_approval` char(1) NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT '0',
  `addtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastlogin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`USERID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`USERID`, `gender`, `firstname`, `lastname`, `organization_name`, `group_type`, `email`, `username`, `password`, `photo`, `birthday`, `address`, `city`, `postal_code`, `directory_listing_approval`, `submit_request_approval`, `status`, `addtime`, `lastlogin`) VALUES
(1, 'male', 'Bhupinder', 'Singh', 'DAV Chandigarh', 4, 'thakur.bhupinder@gmail.com', 'bhupinder', '05fe7461c607c33229772d402505601016a7d0ea', 'source_image12.jpg', '1983-07-26', 'DAV School, Near Shanti Kunj,\nSector 24-D, Chandigarh', 'Chandigarh', '160062', '1', '1', '1', '2013-10-27 06:18:40', '0000-00-00 00:00:00'),
(2, 'female', 'Charvi', 'Thakur', 'Pooja Mills', 8, 'charvi.thakur@gmail.com', 'charvi', '6bad02217377d3087d21a80bde3f896eca7b7b62', 'noimage.png', '2010-07-28', '', 'Hamirpur', 'Himachal Pradesh', '0', '0', '0', '2013-09-28 11:56:51', '0000-00-00 00:00:00'),
(3, 'male', 'Wasim', 'ismail', 'alrayes', 1, 'email@wasimismail.com', 'iwas1m', '06c7d6c133bf6f2eac4db4f72c154e1394d86481', '60021.jpg', '1990-02-02', 'test', 'test', 'tes', '0', '0', '1', '2013-10-23 09:48:12', '0000-00-00 00:00:00'),
(4, 'male', 'Wasim Test', 'test 2', 'Sawana', 1, 'wasim@alrayes.co.uk', 'sawana', '4381e403834b71eb6564925ea8b047cdf2042d2a', '60022.jpg', '1985-02-01', 'test address', 'test city', 'test post', '0', '1', '1', '2013-10-28 11:09:25', '0000-00-00 00:00:00'),
(5, 'male', 'Sarfraz', 'Khan', 'Near Neighbours Highfields', 1, 'sarfraznawazkhan@gmail.com', 'sarfraz', 'c0b137fe2d792459f26ff763cce44574a5b5ab03', 'LLH_badge.jpg', '1982-01-06', 'St Peter''s Church\nSt Peters Road\nHighfields', 'Leicester', 'LE51LL', '1', '1', '1', '2013-10-31 12:28:49', '0000-00-00 00:00:00'),
(6, 'female', 'Naeem', 'Aqsa', 'Aqsa', 4, 'wasim@wasimismail.com', 'aqsa', '4381e403834b71eb6564925ea8b047cdf2042d2a', 'noimage.png', '1990-02-01', 'test\ntest', 'test', 'test', '1', '1', '1', '2013-11-03 12:22:20', '0000-00-00 00:00:00'),
(7, 'female', 'aqsa', 'Maryam', 'Wasim Test', 3, 'aqsa@wasimismail.com', 'aqsa1', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', 'noimage.png', '1990-02-01', 't', 'r', 'city', '0', '0', '0', '2013-11-03 03:04:29', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `MENUID` int(11) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(200) NOT NULL,
  PRIMARY KEY (`MENUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `menu_links`
--

CREATE TABLE IF NOT EXISTS `menu_links` (
  `menu_id` int(11) NOT NULL,
  `meta_key` varchar(100) NOT NULL,
  `meta_value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `ID` bigint(30) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(150) NOT NULL,
  `value` text NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT 'noimage.png',
  `post_type` varchar(20) NOT NULL DEFAULT 'page',
  `meta_keyword` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_status` char(50) NOT NULL DEFAULT 'published',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`ID`, `title`, `post_name`, `value`, `image`, `post_type`, `meta_keyword`, `meta_description`, `post_date`, `post_status`) VALUES
(1, 'About Poverty Project', 'about-poverty-project', '<p>Leicester League of Heroes is a project which has been created as a response to local poverty needs.</p>\n\n<p>About 2 years ago, Near Neighbours community workers in Highfields, Belgrave and West End were researching their areas and comparing notes about issues which may affect all their areas and poverty was one of them. At first, some of the child poverty numbers we came across seemed unreal (over 25,000 in the city), but as the reality sunk in, it fast became a priority area.</p>\n\n<p>At first it was difficult to try find a solution, especially as we were looking for a solution that could be applied to any part of Leicester. Often projects are deployed, but only to parts of the city and this is where some communities or families might be overlooked. We wanted to ensure that anyone living in the city of Leicester could take advantage of this project.</p>\n\n<p>After much thinking and wondering if we would find a viable solution, the solution came to us. We started to ask questions to various members of staff and volunteers about the work they do in communities and what could make their jobs easier. In other words, all we had to do was to listen :)</p>\n\n<p>Some of the things we learnt from this were:</p>\n\n<ul>\n	<li>\n	<p>There is no online portal that unites the different services</p>\n	</li>\n	<li>\n	<p>Information on sites is not always up to date</p>\n	</li>\n	<li>\n	<p>It is hard to navigate and find what you are looking for online</p>\n	</li>\n	<li>\n	<p>Signposting is difficult as it is hard to find all the information in one place</p>\n	</li>\n	<li>\n	<p>When signposting, you never know if the person will receive what they are looking for</p>\n	</li>\n	<li>\n	<p>Updating details or information on websites is generally a pain and more than often, it requires someone who knows how to work the backend of the website to make the changes.</p>\n	</li>\n</ul>\n\n<p><span style="line-height:1.6em">Using the information above along with what other groups and organisations are doing, we designed a website which is easy to use for both; the groups and organisations as well as the residents of our great city. Using a social network style interface, combined with a superhero theme, we hope to have put together a site which is easily accessible, simple to use, inspirational for our younger residents and helpful in addressing poverty needs in our city.</span></p>\n\n<p>&nbsp;</p>\n', 'noimage.png', 'page', '', '', '2013-11-05 09:26:28', 'published'),
(2, 'Contact Us', 'contact-us', '<p>The Leicester League of Heroes website has been designed to ensure ease of use compared to traditional websites. However, if you are unsure, or would like to ask any questions, please feel free to contact us using the email provided below:\n </p>\n<p>General enquiries: <a href="mailto:info@lloh.co.uk">info@lloh.co.uk  </a></p>\n<p>We currently do not have a contact number as we are new and jut getting started, but we will try our best to get one up as soon as possible :) </p>\n', 'noimage.png', 'page', '', '', '2013-10-26 12:58:11', 'published'),
(3, 'Privacy Policy', 'privacy-policy', '<p>The Leicester League of Heroes is committed to protecting your privacy and maintaining the security of any personal information received from you. We strictly adhere to the requirements of data protection legislation in the UK.</p>\n\n<p>The purpose of this statement is to explain to you what personal information we collect and how we may use it.</p>\n\n<p>When you get in touch with us we may ask you for your contact details in case we need to get back in touch with you or call you back.</p>\n\n<p>We may use your personal information to<br />\n- update you about new products/services<br />\n- improve our products/services<br />\n- conduct research<br />\n- respond to your query</p>\n\n<p>We do not sell, rent or exchange your personal information with any third party for commercial reasons.</p>\n\n<p>We follow strict security procedures in the storage and disclosure of information which you have given us, to prevent unauthorised access in accordance with the UK data protection legislation.</p>\n\n<p>We do not collect sensitive information about you except when you specifically knowingly provide it. In order to maintain the accuracy of our database, you can check, update or remove your personal details by emailing us.</p>\n\n<p>We will not transfer your information outside of the EEA (European Economic Area) without first obtaining your consent.</p>\n\n<h3>Cookies (the computer kind not the ones you eat)</h3>\n\n<p>A cookie is a small file which asks permission to be placed on your computer&rsquo;s hard drive. Once you agree, the file is added and the cookie helps analyse web traffic or lets you know when you visit a particular site. Cookies allow web applications to respond to you as an individual. The web application can tailor its operations to your needs, likes and dislikes by gathering and remembering information about your preferences.</p>\n\n<p>Leicester League of Heroes uses traffic log cookies to identify which pages are being used. This helps us analyse data about web page traffic and improve the website in order to tailor it to our visitor&#39;s needs. We only use this information for statistical analysis purposes and then the data is removed from the system.</p>\n\n<p>Overall, cookies help us provide you with a better website, by enabling us to monitor which pages you find useful and which you do not. A cookie in no way gives us access to your computer or any information about you, other than the data you have chosen to share with us.</p>\n\n<p>You can choose to accept or decline cookies. Most web browsers automatically accept cookies, but you can usually modify your browser settings to decline cookies if you prefer. This may prevent you from taking full advantage of the website. We take your privacy very seriously and comply with the recent UK and EU law on handling cookies and provide (you) the user with means to remove such cookies or prevent your computer from accepting them in the future.</p>\n', 'noimage.png', 'page', '', '', '2013-10-26 12:57:21', 'published'),
(4, 'Terms & Conditions', 'terms-conditions', '<p><strong>Leicester League of Heroes (LLH) Rules and Regulations</strong><br />\nThe LLH website is a portal for charities, groups, organisations, faith buildings and educational institutes to work together to help families living in poverty in the area. The website has been designed for ease of use not only for the above mentioned entities but also for individuals who wish to help, thereby encouraging and empowering local people to help one another regardless of faith, culture or race.</p>\n\n<p><strong>1. The LLH Primary Objectives</strong><br />\n1.1) to help solve identified poverty issues that individuals or families may face in a simple and easy way<br />\n1.2) to encourage and empower Leicester locals to help those who are in need</p>\n\n<p><strong>2. LLH Secondary Objectives</strong><br />\n2.1) to help charities, groups, organisations and faith buildings network and engage with one another and the public<br />\n2.2) to highlight the good work done by charities, groups, organisations and faith buildings</p>\n\n<p><strong>3. Ownership</strong><br />\nAlthough the website is owned by the Nehemiah Foundation, it is not dictated by it. The site is a tool designed for services providers in the city to take advantage of and has been put together through feedback collated from local groups, organisations, institutes and residents.</p>\n\n<p><strong>4. Things that you can request on LLH website</strong><br />\n4.1) Clothing<br />\n4.2) Food and drink<br />\n4.3) Bedding<br />\n4.4) Hygiene products<br />\n4.5) Baby products such as milk, bottles, bibs, nappies etc<br />\n4.6) Volunteers for projects and events which may benefit the community&rsquo;s needs and concerns (please check the volunteer sub section)</p>\n\n<p><strong>5. Things that you cannot request on the LLH website</strong><br />\n5.1) Money<br />\n5.2) Branded products<br />\n5.3) Electronic products e.g. mobile phones, tablets, pc&rsquo;s, consoles and anything which may fall under a sub category of the above mentioned products.<br />\n5.4) Beauty products such as: hair dryers, straighteners, make up, aftershave etc<br />\n5.5) Products and goods for an event and or project that is more of a requirement and or necessity for the charity, group, organisation, faith building and or educational institute than the primary objectives set out in section 1.</p>\n\n<p><strong>6. Requesting volunteers</strong><br />\nWhen requesting volunteers for a project or event, the group, organisation, charity, faith building and or educational institute must have the following:<br />\n6.1) All relevant policies required to safeguard volunteers and staff.<br />\n6.2) Public Liability Insurance and Employers Liability Insurance that cover the volunteers and the work they may be asked to do.<br />\n6.3) Volunteers are not be chosen and or requested based on their race, religion, gender and or sexuality.<br />\n6.4) If volunteers are below the age of 18, then all relevant precautions are taken into consideration before taking them on. i.e. Parental consent etc</p>\n\n<p><strong>7. What to do if unsure of posting a request</strong><br />\n7.1) Check if what you are requesting falls into the primary objectives of the JLL website.<br />\n7.2) Check against sections 4, 5 and 6 to make sure it fits the criteria set within them.<br />\n7.3) If still unsure, please contact us on the details provided.</p>\n\n<p><strong>8. What happens if we post something which goes against the objectives and criteria?</strong><br />\nEach case will be handled individually and the outcome will depend on the severity of the action. This can be anything from temporary suspension from posting on the site to permanent suspension from using the website to make posts. If any donations have already been made, we will ask you to return them to whoever has made them within 10 working days.</p>\n\n<p><strong>9. Health and Safety</strong><br />\nWhen requesting any product, electrical or non-electrical, it is the responsibility of the organisation making the request to ensure the donation is safe for use.<br />\n&middot; Ensure the product is hygienically safe<br />\n&middot; Ensure the electrical product is in working order and safe to use<br />\n&middot; Ensure the food is safe to eat and subjects such as allergies and diets are taken into consideration and addressed as necessary</p>\n\n<p><strong>10. Responsibility</strong><br />\n10.1) The responsibility of adhering to points 4 through to 9 remains with the group / organisation / institute and not with LLH.<br />\n10.2) LLH will take the responsibility of ensuring the website is monitored and if rules and regulations are broken, to take necessary action.<br />\n10.3) LLH will also ensure that only trusted groups / organisations / institutes are given a password. This will be determined via a database from the Leicester City Council and Voluntary Action Leicester. Any new groups / organisations / institutions may need to provide necessary paperwork and a site visit may be required.</p>\n\n<p>&nbsp;</p>\n', 'noimage.png', 'page', '', '', '2013-10-26 12:51:05', 'published'),
(5, 'Global Poverty Project', 'global-poverty-project', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ante est, hendrerit non egestas non, scelerisque quis est. Phasellus at tempor velit, nec faucibus ligula. Nullam sed placerat tortor, ac placerat purus. Pellentesque consectetur dapibus nisl, vestibulum faucibus quam. Maecenas gravida nisi nisl, id condimentum tellus pharetra vitae. Nam gravida turpis a erat eleifend hendrerit. Vestibulum ac elit ac ante fringilla ornare. Aliquam erat volutpat. Nunc aliquet feugiat ante nec adipiscing. Duis ullamcorper, justo pellentesque scelerisque tempus, massa leo eleifend nulla, quis varius ligula neque non felis. Phasellus pretium, quam non suscipit condimentum, nisl dolor mattis ipsum, in varius nulla est vel arcu. Vivamus sit amet lorem in quam tempus hendrerit. Maecenas fermentum arcu a mi porttitor, non malesuada sapien convallis. Donec a lorem eu odio tempus facilisis non vitae leo.&nbsp;<br />\n<br />\nMauris lobortis at odio suscipit rutrum. Nulla facilisi. Sed adipiscing tellus odio, vel semper turpis pulvinar consequat. Cras sed tempor eros. Nunc gravida sapien a mattis pretium. Fusce in tristique tortor, sit amet semper quam. Maecenas pellentesque posuere erat et ultricies. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc rhoncus nisl sit amet sem consequat sollicitudin. Donec sit amet nisi eu risus fringilla pretium. Curabitur sed massa molestie mi molestie adipiscing ac quis sapien.&nbsp;<br />\n<br />\nAenean cursus libero id egestas mollis. Suspendisse sed nisl sapien. Vestibulum auctor placerat velit, quis semper sem. Mauris eget malesuada purus. Proin in velit ac arcu elementum tempus in nec nunc. Pellentesque sed rutrum orci. Nulla pulvinar tincidunt nisi eget elementum. Pellentesque ultrices placerat lorem, at tincidunt sem pretium quis. Integer gravida enim tristique arcu suscipit, sit amet elementum tortor tempus. In a nisl a libero bibendum rhoncus a vitae libero. Sed molestie, ipsum sed ullamcorper molestie, arcu turpis iaculis neque, feugiat semper neque diam interdum est. Vestibulum sit amet pellentesque turpis, quis adipiscing eros. Praesent interdum ipsum est, a vehicula nibh luctus eget. Ut sapien ante, tempor et pellentesque id, molestie rhoncus est. Phasellus vel vulputate justo. Suspendisse potenti.&nbsp;</p>\n', 'usat-poverty.jpg', 'news', '', '', '2013-11-07 19:42:00', 'published'),
(6, 'Member User Guide', 'member-user-guide', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ante est, hendrerit non egestas non, scelerisque quis est. Phasellus at tempor velit, nec faucibus ligula. Nullam sed placerat tortor, ac placerat purus. Pellentesque consectetur dapibus nisl, vestibulum faucibus quam. Maecenas gravida nisi nisl, id condimentum tellus pharetra vitae. Nam gravida turpis a erat eleifend hendrerit. Vestibulum ac elit ac ante fringilla ornare. Aliquam erat volutpat. Nunc aliquet feugiat ante nec adipiscing. Duis ullamcorper, justo pellentesque scelerisque tempus, massa leo eleifend nulla, quis varius ligula neque non felis. Phasellus pretium, quam non suscipit condimentum, nisl dolor mattis ipsum, in varius nulla est vel arcu. Vivamus sit amet lorem in quam tempus hendrerit. Maecenas fermentum arcu a mi porttitor, non malesuada sapien convallis. Donec a lorem eu odio tempus facilisis non vitae leo.<br />\n<br />\nMauris lobortis at odio suscipit rutrum. Nulla facilisi. Sed adipiscing tellus odio, vel semper turpis pulvinar consequat. Cras sed tempor eros. Nunc gravida sapien a mattis pretium. Fusce in tristique tortor, sit amet semper quam. Maecenas pellentesque posuere erat et ultricies. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc rhoncus nisl sit amet sem consequat sollicitudin. Donec sit amet nisi eu risus fringilla pretium. Curabitur sed massa molestie mi molestie adipiscing ac quis sapien.<br />\n<br />\nAenean cursus libero id egestas mollis. Suspendisse sed nisl sapien. Vestibulum auctor placerat velit, quis semper sem. Mauris eget malesuada purus. Proin in velit ac arcu elementum tempus in nec nunc. Pellentesque sed rutrum orci. Nulla pulvinar tincidunt nisi eget elementum. Pellentesque ultrices placerat lorem, at tincidunt sem pretium quis. Integer gravida enim tristique arcu suscipit, sit amet elementum tortor tempus. In a nisl a libero bibendum rhoncus a vitae libero. Sed molestie, ipsum sed ullamcorper molestie, arcu turpis iaculis neque, feugiat semper neque diam interdum est. Vestibulum sit amet pellentesque turpis, quis adipiscing eros. Praesent interdum ipsum est, a vehicula nibh luctus eget. Ut sapien ante, tempor et pellentesque id, molestie rhoncus est. Phasellus vel vulputate justo. Suspendisse potenti.</p>\n', 'noimage.png', 'page', '', '', '2013-11-07 17:22:25', 'published'),
(7, 'How to become a member ', 'how-to-become-a-member', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ante est, hendrerit non egestas non, scelerisque quis est. Phasellus at tempor velit, nec faucibus ligula. Nullam sed placerat tortor, ac placerat purus. Pellentesque consectetur dapibus nisl, vestibulum faucibus quam. Maecenas gravida nisi nisl, id condimentum tellus pharetra vitae. Nam gravida turpis a erat eleifend hendrerit. Vestibulum ac elit ac ante fringilla ornare. Aliquam erat volutpat. Nunc aliquet feugiat ante nec adipiscing. Duis ullamcorper, justo pellentesque scelerisque tempus, massa leo eleifend nulla, quis varius ligula neque non felis. Phasellus pretium, quam non suscipit condimentum, nisl dolor mattis ipsum, in varius nulla est vel arcu. Vivamus sit amet lorem in quam tempus hendrerit. Maecenas fermentum arcu a mi porttitor, non malesuada sapien convallis. Donec a lorem eu odio tempus facilisis non vitae leo.<br />\n<br />\nMauris lobortis at odio suscipit rutrum. Nulla facilisi. Sed adipiscing tellus odio, vel semper turpis pulvinar consequat. Cras sed tempor eros. Nunc gravida sapien a mattis pretium. Fusce in tristique tortor, sit amet semper quam. Maecenas pellentesque posuere erat et ultricies. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc rhoncus nisl sit amet sem consequat sollicitudin. Donec sit amet nisi eu risus fringilla pretium. Curabitur sed massa molestie mi molestie adipiscing ac quis sapien.<br />\n<br />\nAenean cursus libero id egestas mollis. Suspendisse sed nisl sapien. Vestibulum auctor placerat velit, quis semper sem. Mauris eget malesuada purus. Proin in velit ac arcu elementum tempus in nec nunc. Pellentesque sed rutrum orci. Nulla pulvinar tincidunt nisi eget elementum. Pellentesque ultrices placerat lorem, at tincidunt sem pretium quis. Integer gravida enim tristique arcu suscipit, sit amet elementum tortor tempus. In a nisl a libero bibendum rhoncus a vitae libero. Sed molestie, ipsum sed ullamcorper molestie, arcu turpis iaculis neque, feugiat semper neque diam interdum est. Vestibulum sit amet pellentesque turpis, quis adipiscing eros. Praesent interdum ipsum est, a vehicula nibh luctus eget. Ut sapien ante, tempor et pellentesque id, molestie rhoncus est. Phasellus vel vulputate justo. Suspendisse potenti.</p>\n', 'noimage.png', 'page', '', '', '2013-11-07 17:22:48', 'published'),
(8, 'Setting up', 'setting-up', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ante est, hendrerit non egestas non, scelerisque quis est. Phasellus at tempor velit, nec faucibus ligula. Nullam sed placerat tortor, ac placerat purus. Pellentesque consectetur dapibus nisl, vestibulum faucibus quam. Maecenas gravida nisi nisl, id condimentum tellus pharetra vitae. Nam gravida turpis a erat eleifend hendrerit. Vestibulum ac elit ac ante fringilla ornare. Aliquam erat volutpat. Nunc aliquet feugiat ante nec adipiscing. Duis ullamcorper, justo pellentesque scelerisque tempus, massa leo eleifend nulla, quis varius ligula neque non felis. Phasellus pretium, quam non suscipit condimentum, nisl dolor mattis ipsum, in varius nulla est vel arcu. Vivamus sit amet lorem in quam tempus hendrerit. Maecenas fermentum arcu a mi porttitor, non malesuada sapien convallis. Donec a lorem eu odio tempus facilisis non vitae leo.<br />\n<br />\nMauris lobortis at odio suscipit rutrum. Nulla facilisi. Sed adipiscing tellus odio, vel semper turpis pulvinar consequat. Cras sed tempor eros. Nunc gravida sapien a mattis pretium. Fusce in tristique tortor, sit amet semper quam. Maecenas pellentesque posuere erat et ultricies. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc rhoncus nisl sit amet sem consequat sollicitudin. Donec sit amet nisi eu risus fringilla pretium. Curabitur sed massa molestie mi molestie adipiscing ac quis sapien.<br />\n<br />\nAenean cursus libero id egestas mollis. Suspendisse sed nisl sapien. Vestibulum auctor placerat velit, quis semper sem. Mauris eget malesuada purus. Proin in velit ac arcu elementum tempus in nec nunc. Pellentesque sed rutrum orci. Nulla pulvinar tincidunt nisi eget elementum. Pellentesque ultrices placerat lorem, at tincidunt sem pretium quis. Integer gravida enim tristique arcu suscipit, sit amet elementum tortor tempus. In a nisl a libero bibendum rhoncus a vitae libero. Sed molestie, ipsum sed ullamcorper molestie, arcu turpis iaculis neque, feugiat semper neque diam interdum est. Vestibulum sit amet pellentesque turpis, quis adipiscing eros. Praesent interdum ipsum est, a vehicula nibh luctus eget. Ut sapien ante, tempor et pellentesque id, molestie rhoncus est. Phasellus vel vulputate justo. Suspendisse potenti.</p>\n', 'noimage.png', 'page', '', '', '2013-11-07 17:23:08', 'published'),
(9, 'Sustaining your League ', 'sustaining-your-league', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ante est, hendrerit non egestas non, scelerisque quis est. Phasellus at tempor velit, nec faucibus ligula. Nullam sed placerat tortor, ac placerat purus. Pellentesque consectetur dapibus nisl, vestibulum faucibus quam. Maecenas gravida nisi nisl, id condimentum tellus pharetra vitae. Nam gravida turpis a erat eleifend hendrerit. Vestibulum ac elit ac ante fringilla ornare. Aliquam erat volutpat. Nunc aliquet feugiat ante nec adipiscing. Duis ullamcorper, justo pellentesque scelerisque tempus, massa leo eleifend nulla, quis varius ligula neque non felis. Phasellus pretium, quam non suscipit condimentum, nisl dolor mattis ipsum, in varius nulla est vel arcu. Vivamus sit amet lorem in quam tempus hendrerit. Maecenas fermentum arcu a mi porttitor, non malesuada sapien convallis. Donec a lorem eu odio tempus facilisis non vitae leo.<br />\n<br />\nMauris lobortis at odio suscipit rutrum. Nulla facilisi. Sed adipiscing tellus odio, vel semper turpis pulvinar consequat. Cras sed tempor eros. Nunc gravida sapien a mattis pretium. Fusce in tristique tortor, sit amet semper quam. Maecenas pellentesque posuere erat et ultricies. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc rhoncus nisl sit amet sem consequat sollicitudin. Donec sit amet nisi eu risus fringilla pretium. Curabitur sed massa molestie mi molestie adipiscing ac quis sapien.<br />\n<br />\nAenean cursus libero id egestas mollis. Suspendisse sed nisl sapien. Vestibulum auctor placerat velit, quis semper sem. Mauris eget malesuada purus. Proin in velit ac arcu elementum tempus in nec nunc. Pellentesque sed rutrum orci. Nulla pulvinar tincidunt nisi eget elementum. Pellentesque ultrices placerat lorem, at tincidunt sem pretium quis. Integer gravida enim tristique arcu suscipit, sit amet elementum tortor tempus. In a nisl a libero bibendum rhoncus a vitae libero. Sed molestie, ipsum sed ullamcorper molestie, arcu turpis iaculis neque, feugiat semper neque diam interdum est. Vestibulum sit amet pellentesque turpis, quis adipiscing eros. Praesent interdum ipsum est, a vehicula nibh luctus eget. Ut sapien ante, tempor et pellentesque id, molestie rhoncus est. Phasellus vel vulputate justo. Suspendisse potenti.</p>\n', 'noimage.png', 'page', '', '', '2013-11-07 17:23:25', 'published'),
(10, 'Maintaining your League ', 'maintaining-your-league', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ante est, hendrerit non egestas non, scelerisque quis est. Phasellus at tempor velit, nec faucibus ligula. Nullam sed placerat tortor, ac placerat purus. Pellentesque consectetur dapibus nisl, vestibulum faucibus quam. Maecenas gravida nisi nisl, id condimentum tellus pharetra vitae. Nam gravida turpis a erat eleifend hendrerit. Vestibulum ac elit ac ante fringilla ornare. Aliquam erat volutpat. Nunc aliquet feugiat ante nec adipiscing. Duis ullamcorper, justo pellentesque scelerisque tempus, massa leo eleifend nulla, quis varius ligula neque non felis. Phasellus pretium, quam non suscipit condimentum, nisl dolor mattis ipsum, in varius nulla est vel arcu. Vivamus sit amet lorem in quam tempus hendrerit. Maecenas fermentum arcu a mi porttitor, non malesuada sapien convallis. Donec a lorem eu odio tempus facilisis non vitae leo.<br />\n<br />\nMauris lobortis at odio suscipit rutrum. Nulla facilisi. Sed adipiscing tellus odio, vel semper turpis pulvinar consequat. Cras sed tempor eros. Nunc gravida sapien a mattis pretium. Fusce in tristique tortor, sit amet semper quam. Maecenas pellentesque posuere erat et ultricies. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc rhoncus nisl sit amet sem consequat sollicitudin. Donec sit amet nisi eu risus fringilla pretium. Curabitur sed massa molestie mi molestie adipiscing ac quis sapien.<br />\n<br />\nAenean cursus libero id egestas mollis. Suspendisse sed nisl sapien. Vestibulum auctor placerat velit, quis semper sem. Mauris eget malesuada purus. Proin in velit ac arcu elementum tempus in nec nunc. Pellentesque sed rutrum orci. Nulla pulvinar tincidunt nisi eget elementum. Pellentesque ultrices placerat lorem, at tincidunt sem pretium quis. Integer gravida enim tristique arcu suscipit, sit amet elementum tortor tempus. In a nisl a libero bibendum rhoncus a vitae libero. Sed molestie, ipsum sed ullamcorper molestie, arcu turpis iaculis neque, feugiat semper neque diam interdum est. Vestibulum sit amet pellentesque turpis, quis adipiscing eros. Praesent interdum ipsum est, a vehicula nibh luctus eget. Ut sapien ante, tempor et pellentesque id, molestie rhoncus est. Phasellus vel vulputate justo. Suspendisse potenti.</p>\n', 'noimage.png', 'page', '', '', '2013-11-07 17:23:41', 'published'),
(11, 'Lorem ipsum dolor sit amet, consectetur', 'lorem-ipsum-dolor-sit-amet-consectetur', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc sodales tortor ut lacus condimentum tristique. Pellentesque pharetra scelerisque felis et fermentum. Nullam porttitor quis diam nec dignissim. Praesent egestas augue sed turpis semper scelerisque. Etiam eget ullamcorper tellus. Suspendisse pulvinar magna sem, vel viverra justo porta cursus. Aliquam sed risus enim. Ut interdum neque dui. Donec mauris nunc, iaculis a blandit ut, imperdiet a risus. Aliquam sagittis, lacus posuere mollis dictum, lorem est vulputate orci, eget fringilla justo ipsum nec nunc.</p>\n\n<p>Aenean varius dolor nec augue blandit vestibulum. Sed varius eleifend ante, ac iaculis dolor auctor malesuada. Duis nec felis libero. Ut pretium purus a risus ullamcorper, sit amet cursus ligula condimentum. Cras fringilla nec odio fringilla pretium. Proin sed aliquam mauris, ac egestas urna. Nulla nec scelerisque augue, vel posuere turpis. In sit amet est sit amet turpis cursus pharetra. Nullam lobortis iaculis dolor, vitae rhoncus diam tempus sed. Integer euismod congue vestibulum. Ut cursus porta semper. In laoreet, erat blandit faucibus hendrerit, felis magna dictum velit, at adipiscing nibh sem eu odio. Sed a odio arcu.</p>\n\n<ul>\n <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>\n <li>Integer egestas purus gravida, rutrum risus non, ornare nulla.</li>\n <li>Mauris vitae enim vel tortor egestas tempus.</li>\n <li>Proin id felis at tortor tincidunt viverra.</li>\n <li>Duis vel ligula fringilla, dapibus nisi id, porttitor odio.</li>\n <li>Curabitur molestie turpis at libero tempor posuere.</li>\n</ul>\n\n<p>Nam ac sapien est. Vivamus at elit lacinia, condimentum neque eu, adipiscing leo. Vivamus in nisl viverra, pellentesque nisl ut, auctor ligula. Nulla quis risus turpis. Quisque at suscipit eros. Praesent a placerat metus. Vestibulum porta neque enim, et accumsan arcu mollis sed. Sed a mauris sed libero sodales mattis ut eget mi. Etiam eu purus eget sem euismod mattis. Aenean in mauris mollis, eleifend massa vel, accumsan dolor. Nullam vitae sagittis nisl, ut eleifend ipsum.</p>\n', 'bilde.jpg', 'article', 'Aenean, aliquam, leo, ac, dapibus, tincidunt.', 'nteger et tellus eget mi commodo vulputate vel a justo. Morbi faucibus turpis non ipsum consequat lobortis.', '2013-11-07 19:41:33', 'published');

-- --------------------------------------------------------

--
-- Table structure for table `post_a_request`
--

CREATE TABLE IF NOT EXISTS `post_a_request` (
  `POST_ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_name` varchar(200) NOT NULL,
  `photo` varchar(100) NOT NULL DEFAULT 'noimage.png',
  `description` text NOT NULL,
  `quantity_required` int(11) NOT NULL,
  `deadline` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` char(100) NOT NULL DEFAULT 'active',
  `post_approved` char(100) NOT NULL DEFAULT 'published',
  PRIMARY KEY (`POST_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `post_a_request`
--

INSERT INTO `post_a_request` (`POST_ID`, `user_id`, `post_name`, `photo`, `description`, `quantity_required`, `deadline`, `status`, `post_approved`) VALUES
(1, 1, 'School Uniform fringilla eu tristique eget', 'Teach-Girls-End-World-Poverty.jpg', 'Nunc tortor felis, lobortis at semper ut, faucibus et dolor. Cras lacinia ornare dolor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.\r\n\r\nNam interdum odio non sapien eleifend ullamcorper. Phasellus ut luctus leo, vel pulvinar ipsum. Maecenas non mattis sapien, nec tincidunt nibh. Donec in enim nec neque imperdiet iaculis nec sit amet felis. Fusce lacinia metus quis arcu congue, sit amet suscipit orci auctor. Nulla pellentesque congue pharetra. Integer sed nibh malesuada, bibendum sapien eget, euismod ante. Cras at vestibulum orci. Nulla consectetur erat metus, vel ultricies nisi consequat iaculis.\r\n\r\nUt ante magna, lobortis at vulputate eget, hendrerit id nisl. Nulla sit amet augue in tellus cursus vehicula nec at nisl. Quisque orci sapien, venenatis at bibendum quis, faucibus vitae justo. Phasellus vel orci magna. Aenean aliquet nunc a arcu aliquam porta vel sit amet justo. Ut adipiscing libero pellentesque metus varius, tempus aliquam sem bibendum. Pellentesque faucibus dui ac dui dictum sodales. Etiam eleifend, sem eget posuere suscipit, lacus diam blandit ligula, non feugiat lectus quam at orci. Morbi libero tortor, congue nec nunc id, gravida commodo quam. Aliquam erat volutpat. Donec faucibus elit non massa pretium dictum. Duis tempus ut tellus vel tempor. Quisque pretium mauris ut felis ultrices scelerisque id sed velit.\r\n\r\nPellentesque non nisl bibendum eros lacinia sodales. Suspendisse tristique pharetra dolor vestibulum euismod. Cras nisi magna, blandit nec erat quis, euismod eleifend eros.', 10, '2013-10-30 00:00:00', 'expired', 'published'),
(2, 1, 'Healthy Food lectus libero consequat velit libero enim et elit.', 'request_big.jpg', 'Nunc tortor felis, lobortis at semper ut, faucibus et dolor. Cras lacinia ornare dolor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.\r\n\r\nNam interdum odio non sapien eleifend ullamcorper. Phasellus ut luctus leo, vel pulvinar ipsum. Maecenas non mattis sapien, nec tincidunt nibh. Donec in enim nec neque imperdiet iaculis nec sit amet felis. Fusce lacinia metus quis arcu congue, sit amet suscipit orci auctor. Nulla pellentesque congue pharetra. Integer sed nibh malesuada, bibendum sapien eget, euismod ante. Cras at vestibulum orci. Nulla consectetur erat metus, vel ultricies nisi consequat iaculis.\r\n\r\nUt ante magna, lobortis at vulputate eget, hendrerit id nisl. Nulla sit amet augue in tellus cursus vehicula nec at nisl. Quisque orci sapien, venenatis at bibendum quis, faucibus vitae justo. Phasellus vel orci magna. Aenean aliquet nunc a arcu aliquam porta vel sit amet justo. Ut adipiscing libero pellentesque metus varius, tempus aliquam sem bibendum. Pellentesque faucibus dui ac dui dictum sodales. Etiam eleifend, sem eget posuere suscipit, lacus diam blandit ligula, non feugiat lectus quam at orci. Morbi libero tortor, congue nec nunc id, gravida commodo quam. Aliquam erat volutpat. Donec faucibus elit non massa pretium dictum. Duis tempus ut tellus vel tempor. Quisque pretium mauris ut felis ultrices scelerisque id sed velit.\r\n\r\nPellentesque non nisl bibendum eros lacinia sodales. Suspendisse tristique pharetra dolor vestibulum euismod. Cras nisi magna, blandit nec erat quis, euismod eleifend eros.', 5, '2013-10-31 00:00:00', 'expired', 'published'),
(3, 1, 'Toys posuere tincidunt fringilla aucto', 'Tatur_Family_Toy.jpg', 'Quisque dolor ligula, tincidunt in est nec, vulputate blandit massa. Fusce ipsum odio, scelerisque vel lorem sed, suscipit convallis purus. Aliquam dignissim congue risus, sit amet pellentesque lorem aliquam eu. Fusce faucibus laoreet odio. Nulla gravida lacus ut turpis feugiat, eget scelerisque felis adipiscing. Vivamus ultricies dolor at lorem feugiat, in semper ante cursus. Integer auctor mi diam, nec fermentum justo pulvinar sit amet.\r\n\r\nNulla id viverra turpis. Ut sodales bibendum ipsum quis porta. Nulla placerat, magna at facilisis dignissim, mauris ante vestibulum lacus, ut posuere nunc nibh in ante. Vivamus ut ante consequat odio aliquet sollicitudin. Nam ac facilisis sem. Proin vel tortor a dolor feugiat faucibus quis id turpis. Integer at orci malesuada, gravida libero vitae, lobortis lacus. Suspendisse elementum enim augue, egestas porttitor ipsum imperdiet sit amet. Aenean quis congue tellus. In hac habitasse platea dictumst. Nullam placerat placerat ante eu semper. Donec cursus justo eget lacus bibendum lacinia.', 2, '2013-11-02 00:00:00', 'expired', 'published'),
(4, 4, 'A new Laptop', '60023.jpg', 'We need a new laptop for a new child', 1, '2013-11-02 00:00:00', 'expired', 'published'),
(5, 4, 'Shoes', 'IMG_20130828_222647.jpg', 'we need 2  shoes', 2, '2013-11-04 00:00:00', 'expired', 'published'),
(6, 4, 'Winter jacket for a child', 'winter-coats-lands-end-boys-parka.jpg', 'We urgently need a winter coat for an 8 year old b.', 1, '2013-11-28 00:00:00', 'active', 'published'),
(7, 4, 'Boxes of cereal', 'cereal.jpg', 'We are gathering supplies for our food bank and need sugar and nut free varieties.\n\nThis will help feed several families over the cold inter months.', 50, '2013-11-16 00:00:00', 'expired', 'published'),
(8, 5, 'Table needed for School Class', 'IMG_20130829_115117.jpg', 'We need a table test, We need a table test, We need a table test, We need a table test, We need a table test, We need a table test, We need a table test, We need a table test, We need a table test, We need a table test, We need a table test, We need a table test, We need a table test, ', 2, '2013-11-15 00:00:00', 'active', 'published'),
(9, 5, 'Bench Needed', 'IMG_20130827_003951.jpg', 'test test test test test test test test test test test test test test test test test test test test test test test test \ntest test test test test test test test test test test test test test test test test test test test test test test test ', 4, '2013-11-22 00:00:00', 'active', 'published'),
(10, 6, 'cables', 'IMG_20130827_143038.jpg', 'test test', 2, '2013-11-19 00:00:00', 'expired', 'published');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `REVIEW_ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `organization` int(11) NOT NULL,
  `review` text NOT NULL,
  `status` char(100) NOT NULL DEFAULT 'active',
  `date_posted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`REVIEW_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`REVIEW_ID`, `name`, `organization`, `review`, `status`, `date_posted`) VALUES
(1, 'Steve Buckler', 1, 'Consectetur Lorem ipsum dolor sit amet, consectetur adipiscing elit.Integer vulputate est vel neque scelerisque aliquet. Nam placerat, lacus vitae rutrum gravida, dui sem posuere quam.', 'published', '2013-10-07 04:15:00'),
(2, 'Kate', 5, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque dignissim leo quis nulla viverra nec fermentum tortor iaculis. Suspendisse quam risus, ullamcorper a molestie porta, lacinia ut arcu. Mauris molestie consequat lorem, eget tincidunt eros mollis nec. ', 'published', '2013-10-07 04:35:34'),
(3, 'Vali', 8, 'Integer vulputate est vel neque scelerisque aliquet. Nam placerat, lacus vitae rutrum gravida, dui sem posuere quam.', 'published', '2013-10-07 04:37:02'),
(4, 'George', 11, 'Phasellus lorem dui, uLorem ipsum dolor sit amet, consectetur adipiscing elit.', 'published', '2013-10-07 04:37:46'),
(5, 'Ricardo Gerfin', 9, 'Nunc condimentum mauris quis dui scelerisque, vel luctus lectus tempor. In hac habitasse platea dictumst. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc et sem quis urna sagittis sagittis sed pellentesque ante.', 'published', '2013-10-07 06:24:40'),
(6, 'Alexander Rimard', 10, 'Phasellus accumsan nisi vel lectus iaculis tristique. Vestibulum tempor quis massa aliquam interdum. Aenean vitae felis viverra, vestibulum enim non, aliquet tellus.', 'published', '2013-10-07 06:26:20'),
(7, 'Slovenčina', 4, 'Sed malesuada elit eu est vehicula volutpat. Quisque quis mi sit amet urna tempor vestibulum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'published', '2013-10-07 06:27:06'),
(8, 'Greavarto Giglin', 11, 'Cras feugiat metus mauris, ut luctus tellus ultrices sit amet. Vivamus nec metus dui. Donec risus purus, tristique nec libero non, volutpat faucibus sapien.', 'published', '2013-10-07 06:28:08'),
(9, 'Rohit Kumar', 7, 'Donec in fermentum tortor, nec dignissim orci. Duis sapien justo, auctor eu sagittis non, aliquet nec neque.', 'published', '2013-10-07 06:28:51'),
(10, 'Oram Libas', 7, 'Sed leo risus, condimentum sed luctus sed, congue pellentesque lectus. Sed sollicitudin mi leo, vitae bibendum erat mollis sed. Nulla facilisi. Vestibulum risus sem, ultrices sit amet molestie a, elementum id leo.', 'published', '2013-10-07 06:29:47'),
(11, 'Neelam Sarai', 1, 'Nulla facilisi. Nam dictum ipsum at urna euismod, a rutrum leo lobortis. Praesent velit nulla, eleifend eget venenatis consequat, porttitor sed mauris.', 'published', '2013-10-07 06:30:39'),
(12, 'Atul', 4, 'Nam placerat, lacus vitae rutrum gravida, dui sem posuere quam.', 'published', '2013-10-08 06:03:36'),
(13, 'Wasim Alrayes', 1, 'great website thank - thank you for the work', 'published', '2013-10-10 04:45:25'),
(14, 'Atul Sood', 7, 'consectetur adipiscing elit.Integer vulputate est vel neque scelerisque aliquet. Nam placerat, lacus vitae rutrum gravida, dui sem posuere quam.', 'published', '2013-10-27 05:22:47'),
(16, 'Saf', 1, 'apart from a few typos and grammatical bits, it seems to be fine. ', 'published', '2013-10-31 12:37:29'),
(17, 'John Test', 5, 'Thank you for putting together this website, it has helped alot.', 'published', '2013-11-03 11:39:13');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
